# E-Commerce Management System

A full-stack e-commerce management system built with the MERN stack.

## Stack
- React + Vite
- Node.js + Express
- MongoDB + Mongoose
- JWT authentication
- REST APIs

## Features
- Product listing and search
- Product management
- Cart
- Customer registration/login
- Orders
- Admin dashboard
- Responsive UI

## Run locally
### Server
```bash
cd server
npm install
npm run dev
```

### Client
```bash
cd client
npm install
npm run dev
```

Create `server/.env` from `.env.example` and add your MongoDB connection string.
