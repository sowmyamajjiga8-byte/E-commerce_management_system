# E-Commerce Management System — MERN

College-level MERN project with authentication (registration, login, logout) and no role-based authorization.

## Features
- User registration/login/logout using JWT
- Product listing, search and category filter
- Product details
- Add/update/remove cart items
- Place orders and view order history
- MongoDB persistence
- Express REST API
- React frontend

## Setup

### Backend
```bash
cd backend
npm install
cp .env.example .env
# Put your MongoDB connection string and JWT secret in .env
npm run dev
```

### Frontend
```bash
cd frontend
npm install
npm run dev
```

Frontend runs on Vite's default port (usually 5173); backend runs on 5000.

## Important
This project intentionally has authentication but no admin/customer authorization, matching the stated requirement.
