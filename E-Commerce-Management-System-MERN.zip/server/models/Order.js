import mongoose from 'mongoose';
const orderSchema = new mongoose.Schema({
  user:{type:mongoose.Schema.Types.ObjectId,ref:'User'},
  items:[{product:{type:mongoose.Schema.Types.ObjectId,ref:'Product'},name:String,price:Number,quantity:Number}],
  total:{type:Number,required:true},
  status:{type:String,enum:['Pending','Processing','Shipped','Delivered','Cancelled'],default:'Pending'}
},{timestamps:true});
export default mongoose.model('Order',orderSchema);
