import express from 'express';
import Product from '../models/Product.js';
import {protect,adminOnly} from '../middleware/auth.js';
const router=express.Router();

router.get('/',async(req,res)=>{try{const q=req.query.search||'';res.json(await Product.find({name:{$regex:q,$options:'i'}}).sort({createdAt:-1}));}catch(e){res.status(500).json({message:e.message});}});
router.get('/:id',async(req,res)=>{try{res.json(await Product.findById(req.params.id));}catch(e){res.status(404).json({message:'Product not found'});}});
router.post('/',protect,adminOnly,async(req,res)=>{try{res.status(201).json(await Product.create(req.body));}catch(e){res.status(400).json({message:e.message});}});
router.put('/:id',protect,adminOnly,async(req,res)=>{try{res.json(await Product.findByIdAndUpdate(req.params.id,req.body,{new:true}));}catch(e){res.status(400).json({message:e.message});}});
router.delete('/:id',protect,adminOnly,async(req,res)=>{try{await Product.findByIdAndDelete(req.params.id);res.json({message:'Product deleted'});}catch(e){res.status(400).json({message:e.message});}});
export default router;
