import {useEffect,useMemo,useState} from 'react';
import axios from 'axios';

const API='http://localhost:5000/api';
const demoProducts=[
 {id:'1',name:'Wireless Headphones',price:59.99,category:'Electronics',stock:25,description:'Comfortable wireless headphones with clear sound.'},
 {id:'2',name:'Smart Watch',price:89.99,category:'Electronics',stock:18,description:'Fitness tracking and smart notifications.'},
 {id:'3',name:'Casual Backpack',price:39.99,category:'Fashion',stock:30,description:'Lightweight backpack for everyday use.'},
 {id:'4',name:'Running Shoes',price:74.99,category:'Fashion',stock:12,description:'Comfortable shoes for everyday running.'}
];

function App(){
 const [products,setProducts]=useState(demoProducts),[cart,setCart]=useState([]),[search,setSearch]=useState(''),[page,setPage]=useState('home'),[user,setUser]=useState(null),[msg,setMsg]=useState('');
 const filtered=useMemo(()=>products.filter(p=>p.name.toLowerCase().includes(search.toLowerCase())),[products,search]);
 const total=cart.reduce((s,p)=>s+p.price*p.qty,0);
 const add=p=>setCart(c=>{const x=c.find(i=>i.id===p.id);return x?c.map(i=>i.id===p.id?{...i,qty:i.qty+1}:i):[...c,{...p,qty:1}]});
 const remove=id=>setCart(c=>c.filter(i=>i.id!==id));
 const loginDemo=()=>{setUser({name:'Admin User',role:'admin'});setMsg('Demo admin login active');};
 const placeOrder=()=>{if(!cart.length)return;setCart([]);setMsg('Order placed successfully!');setPage('orders');};
 return <div className="app">
  <header><div className="brand">🛍️ E-Commerce Management System</div>
   <nav><button onClick={()=>setPage('home')}>Home</button><button onClick={()=>setPage('products')}>Products</button><button onClick={()=>setPage('dashboard')}>Dashboard</button><button onClick={()=>setPage('orders')}>Orders</button><button className="cart" onClick={()=>setPage('cart')}>Cart ({cart.length})</button></nav>
  </header>
  {msg&&<div className="notice">{msg}<button onClick={()=>setMsg('')}>×</button></div>}
  {page==='home'&&<><section className="hero"><div><span className="pill">MERN STACK PROJECT</span><h1>Everything you need to manage your online store.</h1><p>Manage products, customers, carts and orders from one simple e-commerce platform.</p><button className="primary" onClick={()=>setPage('products')}>Shop Products →</button></div><div className="hero-card">📦<strong>Store Dashboard</strong><span>Products • Orders • Customers</span></div></section><Stats products={products} orders={0}/></>}
  {page==='products'&&<section className="section"><div className="section-head"><div><h2>Products</h2><p>Browse and add products to your cart.</p></div><input placeholder="Search products..." value={search} onChange={e=>setSearch(e.target.value)}/></div><div className="grid">{filtered.map(p=><ProductCard key={p.id} p={p} add={add}/>)}</div></section>}
  {page==='cart'&&<section className="section"><h2>Your Cart</h2>{!cart.length?<Empty text="Your cart is empty."/>:<><div className="cart-list">{cart.map(i=><div className="cart-row" key={i.id}><div><strong>{i.name}</strong><span>Qty: {i.qty}</span></div><b>${(i.price*i.qty).toFixed(2)}</b><button onClick={()=>remove(i.id)}>Remove</button></div>)}</div><div className="checkout"><h3>Total: ${total.toFixed(2)}</h3><button className="primary" onClick={placeOrder}>Place Order</button></div></>}</section>}
  {page==='orders'&&<section className="section"><h2>Orders</h2><div className="order-card"><span>ORD-1001</span><strong>Sample order</strong><em>Delivered</em></div><div className="order-card"><span>ORD-1002</span><strong>Recent cart order</strong><em>Processing</em></div></section>}
  {page==='dashboard'&&<section className="section"><div className="section-head"><div><h2>Admin Dashboard</h2><p>Overview of your e-commerce store.</p></div><button className="primary" onClick={loginDemo}>Admin Demo Login</button></div><Stats products={products} orders={2}/><div className="panel"><h3>Recent activity</h3><p>✓ Product catalog initialized</p><p>✓ Order management module ready</p><p>✓ Customer authentication API ready</p><p>✓ MongoDB integration ready</p></div></section>}
  <footer>© 2026 E-Commerce Management System • MERN Stack</footer>
 </div>
}
function ProductCard({p,add}){return <article className="product"><div className="product-img">🛒</div><div className="product-body"><span className="category">{p.category}</span><h3>{p.name}</h3><p>{p.description}</p><div className="price-row"><b>${p.price.toFixed(2)}</b><button onClick={()=>add(p)}>Add to Cart</button></div></div></article>}
function Stats({products,orders}){return <div className="stats"><div><span>Products</span><b>{products.length}</b></div><div><span>Orders</span><b>{orders}</b></div><div><span>Categories</span><b>{new Set(products.map(p=>p.category)).size}</b></div><div><span>Cart Items</span><b>0+</b></div></div>}
function Empty({text}){return <div className="empty">{text}</div>}
export default App;
